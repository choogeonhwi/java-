package com.lgy.spring_react.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react.dto.TempDto;

public interface TempDao {

    public int getMem(Map<String, String> paramMap);
}
