package com.lgy.spring_react.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lgy.spring_react.dto.TempDto;

public interface TempService {

    public int getMem(HttpServletRequest request);
}
