package com.lgy.spring_mvc_board_jdbc.service;

import org.springframework.ui.Model;

public interface BService {
	public void execute(Model model);
}
