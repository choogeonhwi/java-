package com.lgy.spring_mvc_board_jdbc.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
//	JdbcTemplate 사용하기 위한 참조변수 추가
	public static JdbcTemplate template;
}
