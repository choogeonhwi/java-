package com.lgy.spring_test_member.service;

import org.springframework.ui.Model;

public interface MemService {
	public int execute(Model model);
}
