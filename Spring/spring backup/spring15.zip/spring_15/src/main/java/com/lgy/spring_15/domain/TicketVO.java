package com.lgy.spring_15.domain;

import lombok.Data;

@Data
public class TicketVO {
	private int tno;
	private String owner;
	private String grade;
}
