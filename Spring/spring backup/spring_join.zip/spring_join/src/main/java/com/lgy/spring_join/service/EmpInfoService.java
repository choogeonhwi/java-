package com.lgy.spring_join.service;

import java.util.ArrayList;

import com.lgy.spring_join.dto.EmpDeptDto;

public interface EmpInfoService {
	public ArrayList<EmpDeptDto> list();
}
