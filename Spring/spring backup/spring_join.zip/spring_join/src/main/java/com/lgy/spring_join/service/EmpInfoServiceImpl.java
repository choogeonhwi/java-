package com.lgy.spring_join.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_join.dto.EmpDeptDto;
import com.lgy.spring_join.dao.*;

import lombok.extern.slf4j.Slf4j;

@Service("EmpInfoService")
@Slf4j
public class EmpInfoServiceImpl implements EmpInfoService{
	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public ArrayList<EmpDeptDto> list() {
		log.info("@# EmpInfoServiceImpl.list()");
		
		EmpInfoDao dao = sqlsession.getMapper(EmpInfoDao.class);
		ArrayList<EmpDeptDto> list = dao.list();
		
		return list;
	}

}












