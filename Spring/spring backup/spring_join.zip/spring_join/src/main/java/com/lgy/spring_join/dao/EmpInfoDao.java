package com.lgy.spring_join.dao;

import java.util.ArrayList;

import com.lgy.spring_join.dto.EmpDeptDto;

public interface EmpInfoDao {
	public ArrayList<EmpDeptDto> list();
}
