package com.lgy.spring_join_resultmap.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lgy.spring_join_resultmap.dto.DeptDto;
import com.lgy.spring_join_resultmap.dto.EmpDto;
import com.lgy.spring_join_resultmap.dto.EmpJoinDeptDto;
import com.lgy.spring_join_resultmap.service.EmpInfoService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class EmpInfoController {
	@Autowired
	private EmpInfoService service;
	
	@RequestMapping("/list")
	public String list(Model model) {
		log.info("@# EmpInfoController.list()");
		
		ArrayList<EmpJoinDeptDto> list = service.list();
//		list===>[EmpJoinDeptDto(emps=[EmpDto(empno=7369, ename=SMITH, job=null, mgr=0, hiredate=null
//				, sal=0, comm=0, deptno=20)
//		depts=[DeptDto(deptno=20, dname=RESEARCH, loc=null), DeptDto(deptno=30, dname=SALES, loc=null)
		log.info("@# list===>"+list);
		log.info("@# list getEmps===>"+list.get(0).getEmps());
		log.info("@# list getDepts===>"+list.get(0).getDepts());
		
		ArrayList<EmpDto> empDtos = list.get(0).getEmps();
		ArrayList<DeptDto> deptDtos = list.get(0).getDepts();
		
		model.addAttribute("list", list);
		model.addAttribute("list_emp", empDtos);
		model.addAttribute("list_dept", deptDtos);
		
		return "list";
	}
}

















