package com.lgy.spring_join_resultmap.service;

import java.util.ArrayList;

import com.lgy.spring_join_resultmap.dto.EmpJoinDeptDto;

public interface EmpInfoService {
	public ArrayList<EmpJoinDeptDto> list();
}
