package com.lgy.spring_join_resultmap.dao;

import java.util.ArrayList;

import com.lgy.spring_join_resultmap.dto.EmpJoinDeptDto;

public interface EmpInfoDao {
	public ArrayList<EmpJoinDeptDto> list();
}
