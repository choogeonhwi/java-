package com.lgy.spring_react.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react.dao.TempDao;
import com.lgy.spring_react.dto.TempDto;

import lombok.extern.slf4j.Slf4j;

@Service("TempService")
@Slf4j
public class TempServiceImpl implements TempService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public TempDto getMem(int seq) {
		log.info("@# TempServiceImpl.getMem() start");
		
		TempDao dao = sqlSession.getMapper(TempDao.class);
		TempDto dto = dao.getMem(seq);
		
		log.info("@# TempServiceImpl.getMem() end");
		return dto;
	}

}
