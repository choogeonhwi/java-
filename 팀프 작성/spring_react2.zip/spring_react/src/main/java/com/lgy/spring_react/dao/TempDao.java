package com.lgy.spring_react.dao;

import com.lgy.spring_react.dto.TempDto;

public interface TempDao {

	public TempDto getMem(int seq);
	
}
