package com.lgy.spring_react.controller;

import java.util.HashMap;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.spring_react.dto.TempDto;
import com.lgy.spring_react.service.TempService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ApiController {

	@Autowired
	private TempService service;
	
	@ResponseBody
	@RequestMapping(value="/api")
	public ResponseEntity<HashMap<String, String>> api() {
		log.info("@# api1 start");
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("data", "Hello ~~ React");
		map.put("name", "Ji Wan");
		map.put("age", "25");
		map.put("loc", "Kimhae");
		log.info("@# api1 end");
		
		return new ResponseEntity<HashMap<String,String>>(map,HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value="/api/getMem")
	public ResponseEntity<TempDto> api2() {
		log.info("@# api2 start");
		TempDto dto = null;
		dto = service.getMem(2);
		System.out.println(dto);
		log.info("@# api2 end");
		
		return new ResponseEntity<TempDto>(dto,HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value="/api/reqMem")
	public ResponseEntity<TempDto> api3(HttpServletRequest request) {
		log.info("@# api3 start");
		TempDto dto = null;
		System.out.println(request.getParameter("seq"));
		int seq = Integer.parseInt(request.getParameter("seq"));
		dto = service.getMem(seq);
		log.info("@# api3 end");
		
		return new ResponseEntity<TempDto>(dto,HttpStatus.OK);
	}
	
}
