package com.lgy.project_server.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.lgy.project_server.dto.GatChatDto;
import com.lgy.project_server.dto.GatDto;
import com.lgy.project_server.dto.GatMemDto;
import com.lgy.project_server.dto.GatPlanDto;

public interface GatDao {

	public ArrayList<GatDto> getGat(@Param("search") String search);
	
	public ArrayList<GatDto> searchAll();
	
	public int getTotalPage();
	
	public ArrayList<GatDto> getMemGat(@Param("id") String id);
	
	public ArrayList<GatDto> locationGats(@Param("location1") String location1, @Param("location2") String location2);
	
	public int makeGat(@Param("mem_id") String mem_id, @Param("mem_nName") String mem_nName, @Param("title") String title, @Param("desc") String desc
			, @Param("location1") String location1, @Param("location2") String location2, @Param("file1") String file1
			, @Param("file2") String file2, @Param("fileExt") String fileExt, @Param("fileSize") long fileSize);
	
	public int makeGatNoFile(@Param("mem_id") String mem_id, @Param("mem_nName") String mem_nName
			, @Param("title") String title, @Param("desc") String desc
			, @Param("location1") String location1, @Param("location2") String location2);
	
	public int addGatLeader(@Param("mem_id") String mem_id, @Param("mem_nName") String mem_nName);
	
	public GatDto gatInfo(@Param("id") String id);
	
	public int increGatView(@Param("id") String id);
	
	public ArrayList<GatMemDto> gatMems(@Param("id") String id);
	
	public ArrayList<GatPlanDto> gatPlans(@Param("id") String id);
	
	public ArrayList<GatChatDto> gatChat(@Param("id") String id);
	
	public int joinGat(@Param("gat_id") String gat_id, @Param("mem_id") String mem_id, @Param("mem_nName") String mem_nName);
	
}
