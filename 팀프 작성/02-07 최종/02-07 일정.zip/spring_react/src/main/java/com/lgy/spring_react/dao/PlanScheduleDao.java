package com.lgy.spring_react.dao;

import java.util.Map;

public interface PlanScheduleDao {

    public int putMem(Map<String, String> paramMap);
}



