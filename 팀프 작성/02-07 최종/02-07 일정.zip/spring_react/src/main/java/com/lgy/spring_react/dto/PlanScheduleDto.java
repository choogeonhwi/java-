package com.lgy.spring_react.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanScheduleDto {

	
	private String GAT_PLAN_DATE;
	private String GAT_PLAN_ADDR;
	private	String GAT_PLAN_ADDR2;
	private	String GAT_PLAN_TITLE;
	private	String GAT_PLAN_DESC;

	
	
}
