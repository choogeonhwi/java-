package com.lgy.spring_react.service;

import java.util.HashMap;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react.dao.PlanScheduleDao;

import lombok.extern.slf4j.Slf4j;

@Service("PlanScheduleService")
@Slf4j
public class PlanScheduleServiceImpl implements PlanScheduleService {

    @Autowired
    private SqlSession sqlSession;

    @Override
    public int putMem(HttpServletRequest request) {
        int res = 0;
        Map<String, String> paramMap = new HashMap<>();
        
        // 파라미터가 null이 아닌 경우에만 맵에 추가
        String gatPlanDate = request.getParameter("GAT_PLAN_DATE");
        if (gatPlanDate != null) {
            paramMap.put("GAT_PLAN_DATE", gatPlanDate);
        }
        
        String gatPlanAddr = request.getParameter("GAT_PLAN_ADDR");
        if (gatPlanAddr != null) {
            paramMap.put("GAT_PLAN_ADDR", gatPlanAddr);
        }
        
        String gatPlanAddr2 = request.getParameter("GAT_PLAN_ADDR2");
        if (gatPlanAddr2 != null) {
            paramMap.put("GAT_PLAN_ADDR2", gatPlanAddr2);
        }
        
        String gatPlanTitle = request.getParameter("GAT_PLAN_TITLE");
        if (gatPlanTitle != null) {
            paramMap.put("GAT_PLAN_TITLE", gatPlanTitle);
        }
        
        String gatPlanDesc = request.getParameter("GAT_PLAN_DESC");
        if (gatPlanDesc != null) {
            paramMap.put("GAT_PLAN_DESC", gatPlanDesc);
        }
        
        PlanScheduleDao dao = sqlSession.getMapper(PlanScheduleDao.class);
        res = dao.putMem(paramMap);
        return res; // 성공적으로 처리되었음을 나타내는 값을 반환
    }

}

