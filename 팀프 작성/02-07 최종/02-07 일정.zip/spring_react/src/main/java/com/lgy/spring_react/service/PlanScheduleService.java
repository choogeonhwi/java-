package com.lgy.spring_react.service;

import javax.servlet.http.HttpServletRequest;

public interface PlanScheduleService {

    public int putMem(HttpServletRequest request);
}


