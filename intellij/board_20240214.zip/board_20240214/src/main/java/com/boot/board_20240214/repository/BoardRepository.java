package com.boot.board_20240214.repository;

import com.boot.board_20240214.model.Board;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardRepository  extends JpaRepository<Board,Long> {
}
