package com.boot.board_20240214;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Board20240214ApplicationTests {

	@Test
	void contextLoads() {
	}

}
