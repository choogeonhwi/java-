package com.boot.board_20240214;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Board20240214Application {

	public static void main(String[] args) {
		SpringApplication.run(Board20240214Application.class, args);
	}

}
