package com.boot.board_20240214.service;


import com.boot.board_20240214.model.Role;
import com.boot.board_20240214.model.User;
import com.boot.board_20240214.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserService {




    @Autowired
    private UserRepository userRepository;


    @Autowired
    private PasswordEncoder passwordEncoder;
    public User save(User user){
        log.info("@!#!@@#!@!# save()");

        String encodedPassword= passwordEncoder.encode(user.getPassword());
//암호화
        log.info("!@#@!##@@! encodedPassword -" +encodedPassword);

        user.setPassword(encodedPassword);
        user.setEnabled(true);


        Role role=new Role();
        role.setId(1L);
        user.getRoles().add(role);


        return userRepository.save(user);
    }
}
