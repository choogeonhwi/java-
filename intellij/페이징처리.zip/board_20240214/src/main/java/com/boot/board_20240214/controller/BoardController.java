package com.boot.board_20240214.controller;

import com.boot.board_20240214.model.Board;
import java.util.List;
import java.util.Optional;

import com.boot.board_20240214.repository.BoardRepository;
import com.boot.board_20240214.validator.BoardValidator;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/board")
@Slf4j
public class BoardController {

    @Autowired
    private BoardRepository boardRepository;

    @Autowired
    private BoardValidator boardValidator;

    @GetMapping("/list")
//    public String list(Model model) {
//    public String list(Model model, Pageable pageable) {
    public String list(Model model, @PageableDefault(size= 2) Pageable pageable) {

        log.info("list@@");

//        Page<Board> boards = boardRepository.findAll(PageRequest.of(1, 20));
//        Page<Board> boards = boardRepository.findAll(PageRequest.of(0, 20));
        Page<Board> boards = boardRepository.findAll(pageable);

        int startPage= 1;
        int endPage=boards.getTotalPages();

        model.addAttribute("boards",boards);
        model.addAttribute("startPage",startPage);
        model.addAttribute("endPage",endPage);

//boards.getTotalElements()
//boards.getTotalPages()

        return "board/list";
    }

    @GetMapping("/form")
    public String form(Model model, @RequestParam(required = false) Long id) {

        log.info("get form@@");

        if (id == null){
            model.addAttribute("board",new Board());

        }else {
            Optional<Board> board = boardRepository.findById(id);
//            Board board = boardRepository.findById(id).orElse(null);
            model.addAttribute("board",board);

        }

        return "board/form";

    }
    @PostMapping("/form")
//    public String form(@ModelAttribute Board board, Model model) {
    public String form(@Valid Board board, BindingResult bindingResult) {
        log.info("post form@@");



        boardValidator.validate(board, bindingResult);
        if (bindingResult.hasErrors()) {
            return "board/form";
        }



        boardRepository.save(board);
        return "redirect:/board/list";
    }

}
